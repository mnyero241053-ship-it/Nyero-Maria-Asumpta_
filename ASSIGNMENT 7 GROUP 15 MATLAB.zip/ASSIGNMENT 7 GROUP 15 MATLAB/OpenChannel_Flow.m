% Open-Channel Flow Calculator
    % 1.figure window
    fig = figure('Name', 'Manning Flow Calculator', 'Position', [200, 200, 400, 380],'MenuBar', 'none', 'ToolBar', 'none', 'NumberTitle', 'off');
    labels = {'Width, b (m):', 'Depth, y (m):', 'Slope, S (m/m):', 'Roughness, n:'};
    defaults = [2.5, 1.2, 0.001, 0.013];
    ef = zeros(4, 1);
     % 2.UI inputs
    for i = 1:4
        yPos = 330 - (i * 50);
        uicontrol(fig, 'Style', 'text', 'String', labels{i}, 'Position', [20, yPos, 120, 22], 'HorizontalAlignment', 'left', 'BackgroundColor', get(fig, 'Color'));
        ef(i) = uicontrol(fig, 'Style', 'edit', 'Position', [150, yPos, 200, 26],'String', num2str(defaults(i)), 'BackgroundColor', [1 1 1]);
    end
    % 3. Results label
    res = uicontrol(fig, 'Style', 'text', 'String', 'Click Compute to calculate.', 'Position', [20, 20, 360, 80], 'BackgroundColor', [0.9 0.95 1], 'HorizontalAlignment', 'left');
     % 4. Compute Button
    uicontrol(fig, 'Style', 'pushbutton', 'String', 'Compute Discharge', 'Position', [120, 115, 160, 32], 'Callback', @(~,~) runCalc(ef, res));
function runCalc(ef_handles, res_handle)
    b = str2double(get(ef_handles(1), 'String')); 
    y = str2double(get(ef_handles(2), 'String')); 
    S = str2double(get(ef_handles(3), 'String')); 
    n = str2double(get(ef_handles(4), 'String'));
    
    if any(isnan([b, y, S, n])) || any([b, y, S, n] <= 0)
        set(res_handle, 'String', 'Error: All inputs must be valid numbers > 0.');
        return;
    end
    A = b * y;
    R = A / (b + 2*y); 
    Q = (1/n) * A * (R^(2/3)) * sqrt(S);                                    
    V = Q / A;
     set(res_handle, 'String', sprintf('Area (A): %.3f m^2\nHydraulic R: %.3f m\nVelocity (V: %.3f m/s\nDischarge (Q): %.3f m^3/s', A, R, V, Q));
end