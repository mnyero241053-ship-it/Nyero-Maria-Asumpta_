

clc;
clear;
close all;

% OPTIMAL DESIGN OF A WATER DISTRIBUTION PIPELINE

% Given parameters
L = 2000;       % Pipe length (m)
Q = 0.05;       % Discharge (m3/s)
f = 0.02;       % Darcy friction factor
g = 9.81;       % Gravitational acceleration (m/s2)

% Objective function
% Minimize total cost index

objective = @(D) 1000*L*D.^2 + ...
    5000*(8*f*L*Q^2./(g*pi^2*D.^5));

% Initial guess
D0 = 0.25;

% Lower and upper bounds
lb = 0.1;
ub = 0.6;

% Nonlinear constraints
nonlcon = @(D) deal( ...
    [0.6 - 4*Q/(pi*D^2);
     4*Q/(pi*D^2) - 2.0;
     8*f*L*Q^2/(g*pi^2*D^5) - 10], ...
    []);

% Optimization options
options = optimoptions('fmincon', ...
    'Algorithm','sqp', ...
    'Display','iter');

% Perform optimization
[Dopt,Cmin,exitflag,output] = fmincon( ...
    objective,D0,[],[],[],[],lb,ub,nonlcon,options);

% Calculate optimal hydraulic parameters
Vopt = 4*Q/(pi*Dopt^2);

hfopt = 8*f*L*Q^2/(g*pi^2*Dopt^5);

% Display results
fprintf('\nOPTIMIZATION RESULTS\n');

fprintf('Optimal pipe diameter = %.4f m\n',Dopt);

fprintf('Minimum cost index = %.4f\n',Cmin);

fprintf('Optimal flow velocity = %.4f m/s\n',Vopt);

fprintf('Optimal head loss = %.4f m\n',hfopt);

fprintf('Exit flag = %d\n',exitflag);

% Create diameter values for plotting
Dvalues = linspace(0.1,0.6,200);

% Calculate cost for each diameter
Headloss = 8*f*L*Q^2./(g*pi^2*Dvalues.^5);

Cost = 1000*L*Dvalues.^2 + 5000*Headloss;

% Plot cost against diameter
figure;

plot(Dvalues,Cost,'b','LineWidth',2);

hold on;

plot(Dopt,Cmin,'ro','MarkerSize',9, ...
    'MarkerFaceColor','r');

xlabel('Pipe Diameter (m)');

ylabel('Total Cost Index');

title('Optimal Water Distribution Pipeline Design');

legend('Cost Function','Optimal Diameter');

grid on;

% Plot velocity against diameter
Velocity = 4*Q./(pi*Dvalues.^2);

figure;

plot(Dvalues,Velocity,'m','LineWidth',2);

hold on;

yline(0.6,'--k','Minimum velocity');

yline(2.0,'--r','Maximum velocity');

xlabel('Pipe Diameter (m)');

ylabel('Flow Velocity (m/s)');

title('Flow Velocity versus Pipe Diameter');

grid on;

% Plot head loss against diameter
figure;

plot(Dvalues,Headloss,'g','LineWidth',2);

hold on;

yline(10,'--r','Maximum head loss');

xlabel('Pipe Diameter (m)');

ylabel('Head Loss (m)');

title('Head Loss versus Pipe Diameter');

grid on;
