% WATER PUMPING COST OPTIMIZATION
% Decision variables:
% x(1) = Flow rate of pump 1
% x(2) = Flow rate of pump 2
% Lower and upper bounds
lb = [0 0];
ub = [0.04 0.04];
% Initial guess
x0 = [0.025 0.025];
% Optimization using fmincon
options = optimoptions('fmincon','Algorithm','sqp','Display','iter');
[xopt, fval] = fmincon(@pumpCost, x0,[],[],[],[],lb,ub,[],options);
% Display results
fprintf('Optimal pump 1 flow = %.6f m3/s\n',xopt(1));
fprintf('Optimal pump 2 flow = %.6f m3/s\n',xopt(2));
fprintf('Minimum pumping cost = %.6f per hour\n',fval);
fprintf('Total flow supplied = %.6f m3/s\n',sum(xopt));
% Plot the optimal flow rates
figure;
bar(xopt);
set(gca,'XTickLabel',{'Pump 1','Pump 2'});
ylabel('Flow rate (m3/s)');
title('Optimal Water Pump Flow Rates');
grid on;
% Objective function
function C = pumpCost(x)
Q1 = x(1);
Q2 = x(2);
rho = 1000;
g = 9.81;
Qtotal = Q1 + Q2;
H = 30 + 2000*Qtotal^2;
eta1 = 0.82 - 200*(Q1 - 0.025)^2;
eta2 = 0.80 - 180*(Q2 - 0.022)^2;
P1 = rho*g*Q1*H/(1000*eta1);
P2 = rho*g*Q2*H/(1000*eta2);
tariff = 0.25;
% Penalty for failure to meet demand
penalty = 1e7*max(0,0.05-Qtotal)^2;
C = tariff*(P1+P2) + penalty;
end
