% RESERVOIR WATER RELEASE OPTIMIZATION
% Initial storage
S0 = 80000;
% Water inflow
I = 20000;
% Environmental release
E = 5000;
% Minimum and maximum storage
Smin = 30000;
Smax = 100000;
% Decision variables:
% x(1) = Consumer water release
% x(2) = Final reservoir storage
% Maximize consumer release by minimizing its negative
objective = @(x) -x(1);
% Equality constraint: mass balance
Aeq = [1 1];
beq = S0 + I - E;
% Bounds
lb = [0 Smin];
ub = [S0+I-E Smax];
% Initial guess
x0 = [40000 55000];
% Solve
options = optimoptions('fmincon', 'Algorithm','sqp','Display','iter');
[xopt,fval] = fmincon(objective,x0, [],[],Aeq,beq,lb,ub,[],options);
% Results
release = xopt(1);
storage = xopt(2);
fprintf('Maximum consumer release = %.2f m3\n',release);
fprintf('Final reservoir storage = %.2f m3\n',storage);
fprintf('Environmental release = %.2f m3\n',E);
% Plot results
figure;
bar([release,E,storage]);
set(gca,'XTickLabel',{'Consumer release','Environmental release','Final storage'});
ylabel('Water volume (m3)');
title('Optimized Reservoir Water Balance');
grid on;
